TOOLS BY ALDI — AI CHAT

PENTING:
- API key tidak dimasukkan ke file HTML.
- Karena API key sudah dibagikan di chat, segera cabut/revoke key tersebut di dashboard Groq lalu buat key baru.
- Simpan key baru hanya sebagai environment variable di server.

CARA MENJALANKAN:
1. Install Node.js versi 18 atau lebih baru.
2. Letakkan 111_login_daftar_chat_backend.html, server.js, dan package.json dalam satu folder.
3. Buka terminal pada folder itu, jalankan: npm install
4. Atur environment variable GROQ_API_KEY dengan API key BARU.
   Linux/macOS: export GROQ_API_KEY="KEY_BARU"
   Windows PowerShell: $env:GROQ_API_KEY="KEY_BARU"
5. Jalankan: npm start
6. Buka http://localhost:3000

Catatan:
- File HTML harus dibuka melalui server ini, bukan dengan membuka file:// langsung.
- Untuk dipakai online, deploy backend ke hosting HTTPS dan simpan GROQ_API_KEY di pengaturan Secrets/Environment Variables hosting.
- Login/daftar pada HTML masih memakai LocalStorage di perangkat, bukan autentikasi server.
