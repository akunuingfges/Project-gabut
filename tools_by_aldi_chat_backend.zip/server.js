// Backend proxy Groq untuk Tools by Aldi
// Simpan API key di environment variable GROQ_API_KEY, jangan di HTML.
const express = require('express');
const path = require('path');

const app = express();
app.use(express.json({ limit: '20kb' }));
app.use(express.static(__dirname));

app.post('/api/chat', async (req, res) => {
  try {
    const message = typeof req.body.message === 'string' ? req.body.message.trim() : '';
    if (!message) return res.status(400).json({ error: 'Pesan tidak boleh kosong.' });
    if (message.length > 4000) return res.status(400).json({ error: 'Pesan terlalu panjang.' });

    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) return res.status(503).json({ error: 'API key belum dipasang di server.' });

    const upstream = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        messages: [
          { role: 'system', content: 'Kamu adalah AI cerdas bernama Aldi. Jawab dengan ramah, jelas, dan bahasa Indonesia.' },
          { role: 'user', content: message }
        ],
        temperature: 0.7
      })
    });

    const result = await upstream.json();
    if (!upstream.ok) {
      console.error('Groq API error:', result);
      return res.status(502).json({ error: 'Layanan AI menolak permintaan. Periksa konfigurasi API di server.' });
    }

    const reply = result.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: 'AI tidak mengirim balasan.' });
    res.json({ reply });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Terjadi kesalahan pada server.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Tools by Aldi berjalan di http://localhost:${port}`));
